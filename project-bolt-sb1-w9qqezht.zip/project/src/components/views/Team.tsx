export function Team() {
  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-8">
      <div className="max-w-7xl mx-auto px-4 py-6 md:py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Team</h1>
      </div>
    </div>
  );
}
